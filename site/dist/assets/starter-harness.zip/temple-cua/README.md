# TempleOS starter harness

Six screenshot-based tasks: arithmetic, a loop, a function, strings, directory
navigation, and a file round trip. The actual Cua ComputerAgent owns the model
and action loop. TempleOS QMP input, reset, time budgets and visual grading stay
in the local harness. Other research modules remain available separately.
All ten task definitions and the test suite are included. The four additional
desktop tasks require manual review; the command below selects only the six
starter tasks shown on the website.

Linux, Python 3.11+, and QEMU are required. Use your own OpenAI credential in
OPENAI_API_KEY; credentials are never included in the download.

```sh
python -m venv .venv
.venv/bin/pip install -e '.[cua,dev]'
.venv/bin/temple-cua fetch-iso
.venv/bin/temple-cua prepare --output assets/baseline.qcow2
.venv/bin/temple-cua run --provider cua --model openai/gpt-6.1-sol \
  --baseline assets/baseline.qcow2 --boot-wait 1 \
  --task arithmetic --task sum_of_squares --task triangular_function \
  --task string_statistics --task directory_navigation --task file_roundtrip \
  --max-steps 24 --timeout 300 --api-timeout 90 \
  --max-output-tokens 4096 --cua-image-history 2 --output runs/starter
```

Add `--task arithmetic` to select one task. The generated report and JSONL
trajectories keep screenshots, actions and grading evidence. Visual checks reject
ordinary command echoes, but do not prove every implementation requirement or
hidden filesystem state. See docs/CUA_AGENT.md for the SDK bridge and limits.

The ISO and VM snapshots are obtained locally, not bundled. scripts/qemu-local
is a workspace-specific wrapper; install normal system QEMU on another machine.
